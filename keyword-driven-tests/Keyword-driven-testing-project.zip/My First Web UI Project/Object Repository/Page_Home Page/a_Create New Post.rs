<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Create New Post</name>
   <tag></tag>
   <elementGuidId>8a9fecce-2a92-49b0-984b-fa0e030688b9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='myNavbar']/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3eaa3e77-c31b-4925-be3e-d6b012df3cfd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/simple-blog/redirect/add/post</value>
      <webElementGuid>5e5bdb0e-8637-41d1-99a4-77240d990a13</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Create New Post</value>
      <webElementGuid>a8c94ce3-63d0-4c81-aa47-c2626cbff270</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;myNavbar&quot;)/ul[@class=&quot;nav navbar-nav&quot;]/li[1]/a[1]</value>
      <webElementGuid>658e2a5d-5030-4b73-bce2-68b242ce1f03</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='myNavbar']/ul/li/a</value>
      <webElementGuid>0b1743ef-8594-466b-9559-0dd1c6c029ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Create New Post')]</value>
      <webElementGuid>bdbe8dbf-eeb5-40d4-9322-a1cab8702242</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Too Simple Blog'])[1]/following::a[1]</value>
      <webElementGuid>cb3827d1-4c6b-4fb5-8b5f-5612c89d8ed4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Create New Post']/parent::*</value>
      <webElementGuid>4c7b67a8-e32c-478d-81a7-4be29d958901</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/simple-blog/redirect/add/post')]</value>
      <webElementGuid>e62020a2-fa1f-4fec-9260-7f000acc53a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/a</value>
      <webElementGuid>1662757d-53e2-429c-962e-5ec7c516d826</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/simple-blog/redirect/add/post' and (text() = 'Create New Post' or . = 'Create New Post')]</value>
      <webElementGuid>d5d3b8fc-970d-4fcb-ab68-0a77b64ebdac</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

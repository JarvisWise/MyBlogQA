<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>th_New Post Name For Test 1221</name>
   <tag></tag>
   <elementGuidId>4b93141a-df5c-4143-8652-049c540f0018</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='(Posted by: Test User)'])[1]/preceding::th[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>th.alert.alert-info</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>th</value>
      <webElementGuid>e8337280-d7f5-478e-b3c0-e86488b5b008</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>alert alert-info</value>
      <webElementGuid>392ae8a0-e1f0-4f68-a13d-c400ff6bc984</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>New Post Name For Test 1221</value>
      <webElementGuid>15cf34e2-ca37-4410-9961-7fa69769ed8c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;container-fluid text-center&quot;]/div[@class=&quot;row content my-c&quot;]/div[@class=&quot;col-xs-8 col-xs-offset-2 text-left my&quot;]/div[@class=&quot;well&quot;]/table[@class=&quot;table table-bordered tb-my cp&quot;]/tbody[1]/tr[1]/th[@class=&quot;alert alert-info&quot;]</value>
      <webElementGuid>86789292-2096-4f35-a1d4-d0e5f9e8fe36</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(Posted by: Test User)'])[1]/preceding::th[1]</value>
      <webElementGuid>426a67e6-6adc-47f7-906a-edabd6b818c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(Posted: 2023/05/10 23:18:13)'])[1]/preceding::th[1]</value>
      <webElementGuid>757d1c77-1d3a-4145-a5e9-4e6b1406c103</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='New Post Name For Test 1221']/parent::*</value>
      <webElementGuid>7864ebf0-63bd-46eb-b75c-6a756bbd1a4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th</value>
      <webElementGuid>bb493e18-9900-4ea2-bfb4-8da103ec58cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//th[(text() = 'New Post Name For Test 1221' or . = 'New Post Name For Test 1221')]</value>
      <webElementGuid>f82dc703-de1f-45b3-878b-5bd692f27986</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_This is Test Comment 1221</name>
   <tag></tag>
   <elementGuidId>4156065f-b138-42de-9cff-2201bc2b677c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Reply'])[1]/following::td[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>0c09dfa0-fd9b-4ff6-bd89-299e97849fa8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bg-success</value>
      <webElementGuid>58ab5896-b01f-4439-af26-80cbb7ef238c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>colspan</name>
      <type>Main</type>
      <value>3</value>
      <webElementGuid>772b2b42-56ef-427e-887c-8a5ba8ca075a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>This is Test Comment 1221</value>
      <webElementGuid>8343d1eb-28ac-4521-8aa4-9a1f467803d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;container-fluid text-center&quot;]/div[@class=&quot;row content my-c&quot;]/div[@class=&quot;col-xs-8 col-xs-offset-2 text-left my&quot;]/div[@class=&quot;well&quot;]/table[@class=&quot;table table-bordered tb-my cp&quot;]/tbody[1]/tr[2]/td[@class=&quot;bg-success&quot;]</value>
      <webElementGuid>599ae2dd-10d5-485e-94c0-58c34d92c79c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reply'])[1]/following::td[1]</value>
      <webElementGuid>a463c1be-b931-47d3-b953-92084854389b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(Posted: 2023/05/10 23:26:19)'])[1]/following::td[2]</value>
      <webElementGuid>b4d68e85-7d5c-44fd-a170-aa0ffc7c62f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Test User'])[2]/preceding::td[1]</value>
      <webElementGuid>16297c9e-1303-42cf-9a5b-298a43dddc35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create Comment'])[1]/preceding::td[1]</value>
      <webElementGuid>09a4729d-1988-4157-b8b8-89b6c1cbef0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='This is Test Comment 1221']/parent::*</value>
      <webElementGuid>27a68fd7-cca9-431e-9599-8afd97b87200</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/table/tbody/tr[2]/td</value>
      <webElementGuid>1e6a36bd-08b5-4d3f-aebd-22d5581e4913</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'This is Test Comment 1221' or . = 'This is Test Comment 1221')]</value>
      <webElementGuid>199748d7-2cdf-44ac-ae1f-dfe016cad171</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Profile                                _45b160</name>
   <tag></tag>
   <elementGuidId>b1178766-f043-4803-acae-bb2874a6eee7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.row.content.my-c</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>a9b9798a-1af0-4b4c-9239-a13e621cd63c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>row content my-c</value>
      <webElementGuid>ac6b287e-cb7b-4162-864f-35675e1e647c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> 
         

            
            
                Profile
            
            
                
                    
                        FirstName: 
                        
                    
                    
                        LastName: 
                        
                    
                    
                        Email: 
                        
                    
                    
                        Birthday: 
                        
                    
                    
                    Update Profile
                
            

            
            
                Dashboard
            
            
                
                    
                    
                        
                            
                                
                                    Post Name
                                    Post Date and Time
                                    Comments
                                     
                                
                            
                            
                                
                                    
                                        New Post Name For Test 1221
                                        2023/05/10 23:26:04
                                        1
                                        
                                        View
                                    
                                
                            
                        
                    
                
            

        
    </value>
      <webElementGuid>248c7164-021f-493e-991f-d6ff30b96c68</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;container-fluid text-center&quot;]/div[@class=&quot;row content my-c&quot;]</value>
      <webElementGuid>457ba0fe-02a6-45c6-80ab-dbbc436cc112</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body/div/div</value>
      <webElementGuid>0813e9ca-11c4-472c-b6d1-cd9b9e48e5e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = ' 
         

            
            
                Profile
            
            
                
                    
                        FirstName: 
                        
                    
                    
                        LastName: 
                        
                    
                    
                        Email: 
                        
                    
                    
                        Birthday: 
                        
                    
                    
                    Update Profile
                
            

            
            
                Dashboard
            
            
                
                    
                    
                        
                            
                                
                                    Post Name
                                    Post Date and Time
                                    Comments
                                     
                                
                            
                            
                                
                                    
                                        New Post Name For Test 1221
                                        2023/05/10 23:26:04
                                        1
                                        
                                        View
                                    
                                
                            
                        
                    
                
            

        
    ' or . = ' 
         

            
            
                Profile
            
            
                
                    
                        FirstName: 
                        
                    
                    
                        LastName: 
                        
                    
                    
                        Email: 
                        
                    
                    
                        Birthday: 
                        
                    
                    
                    Update Profile
                
            

            
            
                Dashboard
            
            
                
                    
                    
                        
                            
                                
                                    Post Name
                                    Post Date and Time
                                    Comments
                                     
                                
                            
                            
                                
                                    
                                        New Post Name For Test 1221
                                        2023/05/10 23:26:04
                                        1
                                        
                                        View
                                    
                                
                            
                        
                    
                
            

        
    ')]</value>
      <webElementGuid>eb63268d-01d8-4154-add9-ea5e1b46d042</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

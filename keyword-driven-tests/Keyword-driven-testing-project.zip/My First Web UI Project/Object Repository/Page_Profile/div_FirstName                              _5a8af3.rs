<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_FirstName                              _5a8af3</name>
   <tag></tag>
   <elementGuidId>30703825-91cf-4fe3-9ba9-af734e4a6399</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Profile'])[2]/following::div[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.well</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>ef5ef971-8b64-4fc0-904e-7300fca8ccfc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>well</value>
      <webElementGuid>a3ecbf90-94e4-4646-879b-f0cae39cd759</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        FirstName: 
                        
                    
                    
                        LastName: 
                        
                    
                    
                        Email: 
                        
                    
                    
                        Birthday: 
                        
                    
                    
                    Update Profile
                
            </value>
      <webElementGuid>55a55fe5-155b-4b6d-bce2-bbdc08287e31</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;container-fluid text-center&quot;]/div[@class=&quot;row content my-c&quot;]/div[@class=&quot;col-xs-8 col-xs-offset-2 text-left my&quot;]/div[@class=&quot;well&quot;]</value>
      <webElementGuid>69fe616e-b068-42eb-b19a-4f60d3769993</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profile'])[2]/following::div[1]</value>
      <webElementGuid>2885a074-d892-43ea-9dd5-e5f0f0bbb7dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]</value>
      <webElementGuid>d27a9248-4a61-42ea-8338-ba77a50f949a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                
                    
                        FirstName: 
                        
                    
                    
                        LastName: 
                        
                    
                    
                        Email: 
                        
                    
                    
                        Birthday: 
                        
                    
                    
                    Update Profile
                
            ' or . = '
                
                    
                        FirstName: 
                        
                    
                    
                        LastName: 
                        
                    
                    
                        Email: 
                        
                    
                    
                        Birthday: 
                        
                    
                    
                    Update Profile
                
            ')]</value>
      <webElementGuid>1fdfcdb0-8d99-4aba-83ee-550da359c584</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

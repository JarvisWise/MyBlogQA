<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Forgot password</name>
   <tag></tag>
   <elementGuidId>06ca663d-3670-441d-8bed-74e3696e16d3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Forgot password?')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-md-6.d-flex.justify-content-center.my-login > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>ab2cd442-b2cf-451d-a1a9-243955190d6a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/simple-blog/redirect/forgot-password;jsessionid=_fMHXPjLT4EM-c46XpYqta1v1Q1fOAzNYBRfwGbzO7bNQJdcvoMs!-402322966</value>
      <webElementGuid>ed5a8823-4e3a-41d9-8f4e-8639fa18d96e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Forgot password?</value>
      <webElementGuid>bea69e3a-dc4c-46bf-ae8d-7b7f73b2f257</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;container-fluid text-center&quot;]/div[@class=&quot;row content&quot;]/div[@class=&quot;col-sm-6 text-center my-login&quot;]/form[1]/div[@class=&quot;row mb-4&quot;]/div[@class=&quot;col-md-6 d-flex justify-content-center my-login&quot;]/a[1]</value>
      <webElementGuid>c163c88b-3958-4e5f-9afb-d2853fc7f0f2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Forgot password?')]</value>
      <webElementGuid>6e2f3698-87e5-409f-b68c-69f65186ef6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Remember me'])[1]/following::a[1]</value>
      <webElementGuid>f32ea1d3-5f2e-4138-8cee-257080653585</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password:'])[1]/following::a[1]</value>
      <webElementGuid>712e7ab7-3057-4f07-bcd6-85a788de2325</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/preceding::a[1]</value>
      <webElementGuid>9f9b7eb7-f9fa-4889-8954-bbefcad3a268</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Registration'])[1]/preceding::a[1]</value>
      <webElementGuid>5bfd3f20-8201-4469-a195-1450c1639557</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Forgot password?']/parent::*</value>
      <webElementGuid>f868e81c-9808-4e10-9525-3719675ee9a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/simple-blog/redirect/forgot-password;jsessionid=_fMHXPjLT4EM-c46XpYqta1v1Q1fOAzNYBRfwGbzO7bNQJdcvoMs!-402322966')]</value>
      <webElementGuid>be1f3000-8787-4b69-a731-599969b68115</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/a</value>
      <webElementGuid>7f694df4-e631-4a41-bda0-d456cad82a75</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/simple-blog/redirect/forgot-password;jsessionid=_fMHXPjLT4EM-c46XpYqta1v1Q1fOAzNYBRfwGbzO7bNQJdcvoMs!-402322966' and (text() = 'Forgot password?' or . = 'Forgot password?')]</value>
      <webElementGuid>eb768bcd-1e21-4682-9320-e0809de1a132</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/simple-blog/redirect/forgot-password;jsessionid=JREHW48weQh50iyCcH3ldAITK-fYI5lbq1bRAW3Gc17mraCzQtVK!-402322966')]</value>
      <webElementGuid>9af81149-d8af-4dca-915c-86f8a8d6579c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/simple-blog/redirect/forgot-password;jsessionid=JREHW48weQh50iyCcH3ldAITK-fYI5lbq1bRAW3Gc17mraCzQtVK!-402322966' and (text() = 'Forgot password?' or . = 'Forgot password?')]</value>
      <webElementGuid>b88c2543-3c9a-42e5-af4d-57c0665fa198</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
